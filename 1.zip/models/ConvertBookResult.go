package models

// 转换结果
type ConvertBookResult struct {
	PDFPath  string
	EpubPath string
	MobiPath string
	WordPath string
}
