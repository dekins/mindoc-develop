package models


type BlogResult struct{

}