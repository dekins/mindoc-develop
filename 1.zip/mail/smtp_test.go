package mail

import (
	"os"
	"testing"
)

func TestSend(t *testing.T) {
	conf := &SMTPConfig{
		Username: "swh@adm***.com",
		Password: "",
		Host:     "smtp.exmail.qq.com",
		Port:     465,
		Secure:   "SSL",
	}
	c := NewSMTPClient(conf)
	m := NewMail()
	m.AddTo("brother <1556****@qq.com>")
	m.AddFrom("hank <" + conf.Username + ">")
	m.AddSubject("Testing")
	m.AddText("Some text :)")
	filepath, _ := os.Getwd()
	m.AddAttachment(filepath + "/README.md")
	if e := c.Send(m); e != nil {
		t.Error(e)
	} else {
		t.Log("发送成功")
	}
}
