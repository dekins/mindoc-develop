package utils

func Asset(p string, cdn string) string {
	return cdn + p
}
